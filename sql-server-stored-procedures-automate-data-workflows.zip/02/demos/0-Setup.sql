USE master;
GO

/* Check and drop the School database if it exists to start fresh */
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'School')
BEGIN
    -- Set the database to single-user mode to disconnect all existing connections
    ALTER DATABASE School SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    -- Drop the School database
    DROP DATABASE School;
END;
GO

/* Create the School database */
CREATE DATABASE School;
GO

/* Switch context to the newly created School database */
USE School;
GO

/* Create the Students table */
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(100),
    Class VARCHAR(50)
);
GO

/* Create the Marks table with a foreign key reference to Students */
CREATE TABLE Marks (
    MarkID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT,
    SubjectName VARCHAR(100),
    MarkObtained DECIMAL(5, 2)
);
GO

/* Insert sample data into the Students table */
INSERT INTO Students (StudentID, StudentName, Class) VALUES
(1, 'Alex Johnson', '10A'),
(2, 'Ben Smith', '10B'),
(3, 'Chuck Brown', '10A'),
(4, 'Diana Wilson', '10C'); -- Diana Wilson will not have any marks
GO

/* Insert sample data into the Marks table */
INSERT INTO Marks (StudentID, SubjectName, MarkObtained) VALUES
(1, 'Mathematics', 88.50),
(1, 'History', 79.01),
(2, 'Mathematics', 92.99),
(3, 'History', 76.49),
(NULL, 'Science', NULL); -- An entry with no corresponding student
GO

/* Insert additional data into the Students table showcasing different data cases */
INSERT INTO Students (StudentID, StudentName, Class) VALUES
(5, '        EVAN Granger  ', '10a'),    -- Leading/trailing spaces and mixed case in Class
(6, 'fiona michael-s', '10B'),  -- Special character in name
(7, 'George  Tribbian', '10A'), -- Extra spaces in name
(8, ' hannah porter ', '10c');  -- Entirely lowercase with leading/trailing spaces
GO

/* Insert additional data into the Marks table */
INSERT INTO Marks (StudentID, SubjectName, MarkObtained) VALUES
(5, 'Mathematics ', 79.51),     -- Trailing space in subject
(6, 'history', 90.00),          -- Lowercase subject
(7, 'MATHEMATICS', 70.00),      -- Uppercase subject
(8, 'Science.', 95.00),         -- Special character in subject
(8, 'Hist', -88.00);            -- Negative mark for demonstration
GO

/* Create the StudentEnrollments table to track student enrollment dates */
CREATE TABLE StudentEnrollments (
    EnrollmentID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT,
    EnrollmentDate DATE
);
GO

/* Insert enrollment data for students */
INSERT INTO StudentEnrollments (StudentID, EnrollmentDate) VALUES
(1, '2023-01-10'),
(2, '2023-02-15'),
(3, '2023-03-01'),
(4, '2023-03-15'),
(5, '2023-04-01'),
(6, '2023-04-15'),
(7, '2023-05-01'),
(8, '2023-05-15');
GO

/* Create a table to log various operations for demonstration purposes */
CREATE TABLE OperationLogs (
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    OperationType NVARCHAR(100),
    Description NVARCHAR(255),
    OperationDate DATETIME DEFAULT GETDATE()
);
GO

/* Switching context back to School after setup */
USE School;
GO

/* Create a larger version of the Students table to simulate a larger dataset */
CREATE TABLE StudentsLarge (
    StudentID INT IDENTITY(1,1), -- Auto-increment field for StudentID
    StudentName VARCHAR(100),
    Class VARCHAR(50)
);
GO

/* Populate StudentsLarge with data to simulate a larger dataset */
DECLARE @Counter INT = 1; -- Initialize counter
DECLARE @MaxInserts INT = 1000; -- Set the maximum number of insert iterations
DECLARE @TotalStudents INT = (SELECT COUNT(*) FROM Students); -- Get total number of students for name suffix logic

WHILE @Counter <= @MaxInserts
BEGIN
    INSERT INTO StudentsLarge (StudentName, Class)
    SELECT StudentName + CAST(((@Counter - 1) * @TotalStudents + ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS VARCHAR(10)), Class
    FROM Students;
    
    SET @Counter = @Counter + 1; -- Increment counter
END;
GO
