USE School;
GO

/* Create a Procedure Without Parameters: Fetches all student records */
CREATE OR ALTER PROCEDURE sp_SelectAllStudents
AS
BEGIN
    SELECT * FROM Students;
END;
GO

-- To run: Fetch all students
EXEC sp_SelectAllStudents;
GO

/* Create a Procedure Returning Multiple Results: Fetches all students and all marks */
CREATE OR ALTER PROCEDURE sp_GetStudentsAndMarks
AS
BEGIN
    SELECT * FROM Students;
    SELECT * FROM Marks;
END;
GO

-- To run: Get both students and marks in separate result sets
EXEC sp_GetStudentsAndMarks;
GO

/* Create a Procedure with an Input Parameter: Fetches marks for a specific student */
CREATE OR ALTER PROCEDURE sp_GetMarksForStudent
    @StudentID INT
AS
BEGIN
    SELECT * FROM Marks WHERE StudentID = @StudentID;
END;
GO

-- To run: Fetch marks for a student with ID 1
EXEC sp_GetMarksForStudent @StudentID = 1;
GO

/* Create a Procedure with an Output Parameter: 
	Calculates the average mark for a student */
CREATE OR ALTER PROCEDURE sp_GetAverageMark
    @StudentID INT,
    @AverageMark DECIMAL(5, 2) OUTPUT
AS
BEGIN
    SELECT @AverageMark = AVG(MarkObtained) 
	FROM Marks 
	WHERE StudentID = @StudentID;
END;
GO

-- To run: Calculate and retrieve the average mark for a student with ID 1
DECLARE @AvgMark DECIMAL(5,2);
EXEC sp_GetAverageMark @StudentID = 1, @AverageMark = @AvgMark OUTPUT;
SELECT 'Average Mark' = @AvgMark;
GO

DROP PROCEDURE sp_SelectAllStudents;
DROP PROCEDURE sp_GetStudentsAndMarks;
DROP PROCEDURE sp_GetMarksForStudent;
DROP PROCEDURE sp_GetAverageMark;