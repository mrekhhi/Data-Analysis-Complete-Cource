USE School;
GO

/* Defining and Using Input and Output Parameters */
-- Creates a stored procedure to calculate and return the average mark of a student
CREATE OR ALTER PROCEDURE sp_CalculateAverageMark
    @StudentID INT,
    @AverageMark DECIMAL(5,2) OUTPUT
AS
BEGIN
    SELECT @AverageMark = AVG(MarkObtained) FROM Marks WHERE StudentID = @StudentID;
END;
GO

-- Example usage:
DECLARE @AvgMark DECIMAL(5,2);
EXEC sp_CalculateAverageMark @StudentID = 1, @AverageMark = @AvgMark OUTPUT;
PRINT 'Average Mark for Student 1: ' + CAST(@AvgMark AS VARCHAR);
GO

/* Using Optional Parameters */
-- Creates a procedure to fetch students optionally filtered by class
CREATE OR ALTER PROCEDURE sp_GetStudentsByClass
    @Class VARCHAR(50) = NULL -- Optional parameter
AS
BEGIN
    IF @Class IS NULL
        SELECT * FROM Students;
    ELSE
        SELECT * FROM Students WHERE Class = @Class;
END;
GO

-- Example usage without and with the optional parameter:
EXEC sp_GetStudentsByClass;
EXEC sp_GetStudentsByClass @Class = '10A';
GO

/* Dynamic SQL with sp_executesql for Security and Efficiency */
-- Demonstrates executing dynamic SQL commands securely
USE School;
GO

/* Simple Dynamic SQL for Searching Students */
CREATE OR ALTER PROCEDURE sp_SimpleSearchStudents
    @StudentName NVARCHAR(100) = NULL,
    @Class NVARCHAR(50) = NULL
AS
BEGIN
    DECLARE @SQL NVARCHAR(MAX) = 'SELECT * FROM Students WHERE 1=1';
    DECLARE @ParamDefinition NVARCHAR(MAX) = N'@StudentName NVARCHAR(100), @Class NVARCHAR(50)';

    -- Prepare the StudentName parameter for LIKE search
    IF @StudentName IS NOT NULL
        SET @StudentName = '%' + @StudentName + '%';

    -- Append conditions to the SQL statement based on provided parameters
    IF @StudentName IS NOT NULL
        SET @SQL += ' AND StudentName LIKE @StudentName';
        
    IF @Class IS NOT NULL
        SET @SQL += ' AND Class = @Class';

    -- Execute the constructed SQL statement
    EXEC sp_executesql @SQL, @ParamDefinition, @StudentName, @Class;
END;
GO

-- Search by Student Name Only:
EXEC sp_SimpleSearchStudents @StudentName = 'an';
-- Search by Class Only:
EXEC sp_SimpleSearchStudents @Class = '10A';
-- Search by Both Student Name and Class:
EXEC sp_SimpleSearchStudents @StudentName = 'an', @Class = '10A';


-- Clean up 
DROP PROCEDURE IF EXISTS sp_GetStudentsByClass;
DROP PROCEDURE IF EXISTS sp_SimpleSearchStudents;
GO