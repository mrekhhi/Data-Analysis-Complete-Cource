USE School
GO

-- Procedure to update a student's class
CREATE OR ALTER PROCEDURE sp_UpdateStudentClass
    @StudentID INT,
    @NewClass VARCHAR(50)
AS
BEGIN
    UPDATE Students SET Class = @NewClass WHERE StudentID = @StudentID;
END;
GO

-- Procedure to log operations
CREATE OR ALTER PROCEDURE sp_LogOperation
    @Description NVARCHAR(255)
AS
BEGIN
    INSERT INTO OperationLogs (OperationType, Description) 
	VALUES ('Update', @Description);
END;
GO

-- Main procedure for updating student information and logging the operation
CREATE OR ALTER PROCEDURE sp_MainStudentUpdate
    @StudentID INT,
    @NewClass VARCHAR(50)
AS
BEGIN
    DECLARE @Description NVARCHAR(255); -- Declare a variable for the description

    -- Update student's class
    EXEC sp_UpdateStudentClass @StudentID, @NewClass;
    
    -- Prepare the description
    SET @Description = CONCAT('Updated class for student ID ', CAST(@StudentID AS NVARCHAR), ' to ', @NewClass);
    
    -- Log the operation
    EXEC sp_LogOperation @Description = @Description; -- Use the variable
END;
GO

-- Select from OperationLogs before the update
SELECT * FROM OperationLogs;
GO

-- Select student information before the update
SELECT StudentID, StudentName, Class
FROM Students
WHERE StudentID = 1;
GO

-- Example execution: Update class for student ID 1 to '11C'
EXEC sp_MainStudentUpdate @StudentID = 1, @NewClass = '11C';
GO

-- Select from OperationLogs after the update
SELECT * FROM OperationLogs;
GO

-- Select student information after the update
SELECT StudentID, StudentName, Class
FROM Students
WHERE StudentID = 1;
GO

-- Clean up: Drop the stored procedures
DROP PROCEDURE IF EXISTS sp_UpdateStudentClass;
DROP PROCEDURE IF EXISTS sp_LogOperation;
DROP PROCEDURE IF EXISTS sp_MainStudentUpdate;
GO