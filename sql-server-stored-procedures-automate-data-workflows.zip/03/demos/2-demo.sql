USE School;
GO

-- Original, non-optimized stored procedure using a cursor
CREATE OR ALTER PROCEDURE sp_ApplyCurveGrading_Original
    @Class VARCHAR(50),
    @CurvePercentage FLOAT
AS
BEGIN
    DECLARE @StudentID INT, @MarkObtained DECIMAL(5,2);

    DECLARE cur_StudentMarks CURSOR FOR
        SELECT s.StudentID, MarkObtained FROM Marks m
        INNER JOIN Students s ON m.StudentID = s.StudentID
        WHERE s.Class = @Class;

    OPEN cur_StudentMarks;

    FETCH NEXT FROM cur_StudentMarks INTO @StudentID, @MarkObtained;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Update each mark by applying the curve percentage
        UPDATE Marks
        SET MarkObtained = @MarkObtained + (@MarkObtained * @CurvePercentage / 100)
        WHERE StudentID = @StudentID

        FETCH NEXT FROM cur_StudentMarks INTO @StudentID, @MarkObtained;
    END

    CLOSE cur_StudentMarks;
    DEALLOCATE cur_StudentMarks;
END;
GO

-- Optimized stored procedure using set-based operation
CREATE OR ALTER PROCEDURE sp_ApplyCurveGrading_Optimized
    @Class VARCHAR(50),
    @CurvePercentage FLOAT
AS
BEGIN
    -- Update marks for all students in the specified class in a single operation
    UPDATE Marks
    SET MarkObtained = MarkObtained + (MarkObtained * @CurvePercentage / 100)
    FROM Marks m
    INNER JOIN Students s ON m.StudentID = s.StudentID
    WHERE s.Class = @Class;
END;
GO

-- Test of Original SP
DECLARE @StartTime DATETIME, @EndTime DATETIME;
-- Get start time
SET @StartTime = GETDATE();
-- Execute the stored procedure
EXEC sp_ApplyCurveGrading_Original @Class = '10B', @CurvePercentage = 5.0;
-- Get end time
SET @EndTime = GETDATE();
-- Calculate and display execution time
SELECT DATEDIFF(MILLISECOND, @StartTime, @EndTime) AS [Execution Time (ms)];
GO

-- Test of Optimized SP
DECLARE @StartTime DATETIME, @EndTime DATETIME;
-- Get start time
SET @StartTime = GETDATE();
-- Execute the stored procedure
EXEC sp_ApplyCurveGrading_Optimized @Class = '10B', @CurvePercentage = 5.0;
-- Get end time
SET @EndTime = GETDATE();
-- Calculate and display execution time
SELECT DATEDIFF(MILLISECOND, @StartTime, @EndTime) AS [Execution Time (ms)];
GO
