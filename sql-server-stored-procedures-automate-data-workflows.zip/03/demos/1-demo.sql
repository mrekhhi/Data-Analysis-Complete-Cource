USE School;
GO

-- Creating the Stored Procedure with Advanced Error Handling
CREATE OR ALTER PROCEDURE sp_InsertStudentWithErrorHandling
    @StudentID INT,
    @StudentName VARCHAR(100),
    @Class VARCHAR(50)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION; -- Start the transaction

        -- Attempt to insert a new student, which might cause primary key violation
        INSERT INTO Students (StudentID, StudentName, Class)
        VALUES (@StudentID, @StudentName, @Class);

        COMMIT TRANSACTION; -- Commit the transaction if successful
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION; -- Rollback the transaction in case of error

        -- Insert error details into OperationLogs
        INSERT INTO OperationLogs (OperationType, Description)
        VALUES ('ERROR', ERROR_MESSAGE());

        -- Re-throw the error for further handling or notification
        THROW;
    END CATCH
END;
GO

-- Attempt to insert a student with an existing ID to generate an error
EXEC sp_InsertStudentWithErrorHandling @StudentID = 9, @StudentName = 'Test Student', @Class = '10B';

-- Verifying Error Logging
SELECT * FROM OperationLogs WHERE OperationType = 'ERROR';
GO

-- Checking data from Students table
SELECT * FROM Students;
GO

-- Clean up 
DROP PROCEDURE sp_InsertStudentWithErrorHandling;
GO