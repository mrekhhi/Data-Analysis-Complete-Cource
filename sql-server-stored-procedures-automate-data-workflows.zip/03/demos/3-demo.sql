USE School;
GO

/* Creating a non-encrypted stored procedure to update a student's mark */
CREATE OR ALTER PROCEDURE sp_UpdateStudentMark
    @StudentID INT,
    @SubjectName VARCHAR(100),
    @NewMark DECIMAL(5,2)
AS
BEGIN
    UPDATE Marks
    SET MarkObtained = @NewMark
    WHERE StudentID = @StudentID AND SubjectName = @SubjectName;
END;
GO

/* Retrieving the definition of the non-encrypted stored procedure */
SELECT OBJECT_DEFINITION (OBJECT_ID('sp_UpdateStudentMark'));
-- This query returns the text of the stored procedure sp_UpdateStudentMark

/* Displaying the text of the non-encrypted stored procedure */
EXEC sp_helptext 'sp_UpdateStudentMark';
-- This command returns the full text of sp_UpdateStudentMark

/* Executing the non-encrypted stored procedure to update marks */
EXEC sp_UpdateStudentMark @StudentID = 1, 
	@SubjectName = 'Mathematics', @NewMark = 95.0;
-- This command updates the mark for a student with ID 1 in Mathematics to 95.0
-- If execution plan is enabled, it will be displayed. 
GO
--- ----------------------------------------------------------------------------

/* Creating an encrypted stored procedure to update a student's mark */
CREATE OR ALTER PROCEDURE sp_UpdateStudentMarkEncrypted
    @StudentID INT,
    @SubjectName VARCHAR(100),
    @NewMark DECIMAL(5,2)
WITH ENCRYPTION
AS
BEGIN
    UPDATE Marks
    SET MarkObtained = @NewMark
    WHERE StudentID = @StudentID AND SubjectName = @SubjectName;
END;
GO

/* Attempting to retrieve the definition of the encrypted stored procedure */
SELECT OBJECT_DEFINITION (OBJECT_ID('sp_UpdateStudentMarkEncrypted'));
-- This query returns NULL because the stored procedure is encrypted

/* Attempting to display the text of the encrypted stored procedure */
EXEC sp_helptext 'sp_UpdateStudentMarkEncrypted';
-- This command returns an error as the text of the stored procedure is encrypted and cannot be displayed

/* Executing the encrypted stored procedure to update marks */
EXEC sp_UpdateStudentMarkEncrypted @StudentID = 1, 
	@SubjectName = 'Mathematics', @NewMark = 95.0;
-- This command updates the mark for a student with ID 1 in Mathematics to 95.0
-- If execution plan is enabled, it will not be displayed. 
