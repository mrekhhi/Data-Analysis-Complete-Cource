SELECT *
FROM [SalesLT].[Product]
CROSS JOIN [SalesLT].[ProductCategory]
CROSS JOIN [SalesLT].[ProductDescription]
CROSS JOIN [SalesLT].[ProductModel]
GO