SELECT *
FROM WideWorldImporters.Sales.Invoices;
GO
SELECT *
FROM WideWorldImporters.Sales.Orders;
GO
SELECT *
FROM WideWorldImporters.Sales.CustomerTransactions;
GO
SELECT *
FROM WideWorldImporters.Sales.SpecialDeals;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrderLines;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrders;
GO
SELECT *
FROM WideWorldImporters.Sales.Invoices;
GO
SELECT *
FROM WideWorldImporters.Sales.Orders;
GO
SELECT *
FROM WideWorldImporters.Sales.CustomerTransactions;
GO
SELECT *
FROM WideWorldImporters.Sales.SpecialDeals;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrderLines;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrders;
GO
SELECT *
FROM WideWorldImporters.Sales.Invoices;
GO
SELECT *
FROM WideWorldImporters.Sales.Orders;
GO
SELECT *
FROM WideWorldImporters.Sales.CustomerTransactions;
GO
SELECT *
FROM WideWorldImporters.Sales.SpecialDeals;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrderLines;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrders;
GO
SELECT *
FROM WideWorldImporters.Sales.Invoices;
GO
SELECT *
FROM WideWorldImporters.Sales.Orders;
GO
SELECT *
FROM WideWorldImporters.Sales.CustomerTransactions;
GO
SELECT *
FROM WideWorldImporters.Sales.SpecialDeals;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrderLines;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrders;
GO
SELECT *
FROM WideWorldImporters.Sales.Invoices;
GO
SELECT *
FROM WideWorldImporters.Sales.Orders;
GO
SELECT *
FROM WideWorldImporters.Sales.CustomerTransactions;
GO
SELECT *
FROM WideWorldImporters.Sales.SpecialDeals;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrderLines;
GO
SELECT *
FROM WideWorldImporters.Purchasing.PurchaseOrders;
GO

