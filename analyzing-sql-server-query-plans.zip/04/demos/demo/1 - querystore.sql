SELECT name, is_query_store_on
FROM sys.databases