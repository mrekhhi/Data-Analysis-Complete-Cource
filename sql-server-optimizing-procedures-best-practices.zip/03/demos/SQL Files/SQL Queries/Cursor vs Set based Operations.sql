/*Return all records*/
SELECT sp.BusinessEntityID
		, sp.TerritoryID
		, sp.SalesQuota
		, sp.CommissionPct
		, sp.SalesYTD
		, sp.SalesLastYear
		, sp.Bonus
		, st.Name AS TerritoryName
		, st.CountryRegionCode
		, st.[Group]
		, st.SalesYTD AS TerritorySalesYTD
		, st.SalesLastYear AS TerritorySalesLastYear
		, st.CostYTD AS TerritoryCostYTD
		, st.CostLastYear AS TerritoryCostLastYear
   FROM Sales.SalesPersonPluralsightDemo AS sp
   INNER JOIN Sales.SalesTerritory AS st ON st.TerritoryID = sp.TerritoryID

/*Updating data with cursor*/
CREATE PROCEDURE updateBonus
AS
BEGIN
SET NOCOUNT ON
DECLARE @BusinessEntityID INT
DECLARE @TerritoryID INT
 
DECLARE BonusCursor CURSOR FOR
SELECT BusinessEntityID
	, TerritoryID
FROM Sales.SalesPersonPluralsightDemo
 
OPEN BonusCursor
 
FETCH NEXT FROM BonusCursor INTO @BusinessEntityID, @TerritoryID
	DECLARE @DepName NVARCHAR(50)
WHILE(@@FETCH_STATUS = 0)
BEGIN
 
	SELECT @TerritoryID = TerritoryID 
	FROM Sales.SalesPersonPluralsightDemo 
	WHERE BusinessEntityID = @BusinessEntityID
 
	IF(@TerritoryID = 2) --US Northeast Bonus 10%
	BEGIN 
	UPDATE Sales.SalesPersonPluralsightDemo 
	SET Bonus = (Bonus * 1.1) 
	WHERE BusinessEntityID = @BusinessEntityID
	END
	ELSE IF(@TerritoryID = 6) --Canada Bonus 20%
	BEGIN 
	UPDATE Sales.SalesPersonPluralsightDemo 
	SET Bonus = (Bonus * 1.2) 
	WHERE BusinessEntityID = @BusinessEntityID
	END
	IF(@TerritoryID = 8) --Germany Bonus 30%
	BEGIN 
	UPDATE Sales.SalesPersonPluralsightDemo 
	SET Bonus = (Bonus * 1.3) 
	WHERE BusinessEntityID = @BusinessEntityID
	END
	
	FETCH NEXT FROM BonusCursor INTO @BusinessEntityID, @TerritoryID
END
 
CLOSE BonusCursor
DEALLOCATE BonusCursor
END

EXECUTE updateBonus

/*Update without cursor*/
ALTER PROCEDURE updateBONUS
AS
BEGIN
SET NOCOUNT ON
UPDATE Sales.SalesPersonPluralsightDemo
SET Bonus = CASE 
				WHEN TerritoryID = 2 THEN (Bonus * 1.1)
				WHEN TerritoryID = 6 THEN (Bonus * 1.2)
				WHEN TerritoryID = 8 THEN (Bonus * 1.3)
		END
FROM Sales.SalesPersonPluralsightDemo
WHERE TerritoryID IN (2,6,8)
END

EXECUTE updateBonus