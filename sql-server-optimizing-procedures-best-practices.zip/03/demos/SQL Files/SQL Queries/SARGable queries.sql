   /*Create non-clustered index on City*/
   CREATE NONCLUSTERED INDEX ix_city ON Person.Address (City)

      /*Create non-clustered index on ModifiedDate*/
   CREATE NONCLUSTERED INDEX ix_modifiedDate ON Person.Address (ModifiedDate)


/*Return all records*/
SELECT sc.AddressID
	, sc.AddressLine1
	, sc.City
	, sc.PostalCode
   FROM Person.Address AS sc
   --WHERE LEFT (city, 2) = 'Al'
   --WHERE sc.City like 'Al%'

   /*Non-SARGable query*/
SELECT sc.AddressID
	, sc.AddressLine1
	, sc.City
	, sc.PostalCode
   FROM Person.Address AS sc
   WHERE LEFT (city, 2) = 'Al'

   /*SARGable query*/
SELECT sc.AddressID
	, sc.AddressLine1
	, sc.City
	, sc.PostalCode
   FROM Person.Address AS sc
   WHERE sc.City like 'Al%'

   /*Non-SARGable query*/
SELECT sc.AddressID
	, sc.AddressLine1
	, sc.City
	, sc.PostalCode
	, sc.ModifiedDate
   FROM Person.Address AS sc
   WHERE YEAR(sc.ModifiedDate) = 2007

      /*SARGable query*/
SELECT sc.AddressID
	, sc.AddressLine1
	, sc.City
	, sc.PostalCode
	, sc.ModifiedDate
   FROM Person.Address AS sc
   WHERE sc.ModifiedDate BETWEEN '20070101' AND '20071231'

