-- find open transactions in SQL Server
select * from sys.dm_exec_sessions
where open_transaction_count > 0





-- works only in the query window where the transaction is running
SELECT @@TRANCOUNT;







-- works only in the query window where the transaction is running
select * from sys.dm_exec_requests
where session_id > 55



-- narrow down which database has open transaction
select * from sys.databases


select * from sys.dm_tran_database_transactions
Where database_id > 4
