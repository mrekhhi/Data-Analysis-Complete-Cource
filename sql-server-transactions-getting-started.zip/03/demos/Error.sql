-- Using @@ERROR in a Transaction

-- Restore AdventureWorks Database, this can be found in the exercise files
USE [AdventureWorks2022]

-- View Table
SELECT * FROM Person.ContactType

-- 
BEGIN TRANSACTION
INSERT INTO Person.ContactType (Name)
VALUES ('Founder')
-- Error Handling
IF(@@ERROR > 0)
	BEGIN 
		ROLLBACK
	END
ELSE 
	BEGIN
		COMMIT 
	END

SELECT @@TRANCOUNT