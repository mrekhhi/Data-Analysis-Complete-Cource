-- Using the ROLLBACK COMMAND

-- Restore AdventureWorks Database, this can be found in the exercise files
USE [AdventureWorks2022]


-- Select Table
SELECT * FROM [AdventureWorks2022].[Sales].[SalesReason]

SELECT @@TRANCOUNT;


-- update the table
BEGIN TRANSACTION
UPDATE [Sales].[SalesReason] 
SET ReasonType = 'Christmas Sales'
WHERE  Name  = 'On Promotion';

SELECT @@TRANCOUNT;

-- Check Table to see if a change took place
SELECT * FROM [AdventureWorks2022].[Sales].[SalesReason]

SELECT @@TRANCOUNT;


-- ROLLBACK
ROLLBACK

-- Check Table Again to see if changes rolled back
SELECT * FROM [AdventureWorks2022].[Sales].[SalesReason]

SELECT @@TRANCOUNT;



--- Automatic rollback

BEGIN TRANSACTION

UPDATE [Sales].[SalesReason] 
SET ReasonType = 'Christmas Sales'
WHERE  Name  = 'On Promotion';

UPDATE [Sales].[SalesReason] 
SET SalesReasonID = 'Go' ---this will fail because SalesReasonID expects an Integer
WHERE  Name  = 'Demo Event';

COMMIT

-- Check Table to see if changes rolled back
SELECT * FROM [AdventureWorks2022].[Sales].[SalesReason]

SELECT @@TRANCOUNT;
