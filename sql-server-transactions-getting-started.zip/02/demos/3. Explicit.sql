-- Explicit Transactions Mode

-- Restore AdventureWorks Database, this can be found in the exercise files
USE [AdventureWorks2022];

-- View Active Transaction
SELECT @@TRANCOUNT;

-- Create Transaction
BEGIN TRANSACTION

SELECT * FROM [Sales].[SalesOrderDetail]
WHERE [SalesOrderDetailID]  = 602;

SELECT @@TRANCOUNT; --select transaction while running

COMMIT TRANSACTION

SELECT @@TRANCOUNT; --select transaction after completion