-- Auto-commit Transactions Mode

-- Restore AdventureWorks Database, this can be found in the exercise files
USE [AdventureWorks2022]

-- Autocommit transaction mode is on by default
-- Each operation will be committed

-- View Active Transaction
SELECT @@TRANCOUNT;






-- Select Table
SELECT * FROM [Sales].[SalesOrderDetail]
WHERE [SalesOrderDetailID]  = 600;

SELECT @@TRANCOUNT;







-- update the table
UPDATE [Sales].[SalesOrderDetail]
SET UnitPrice = 5000
WHERE  [SalesOrderDetailID]  = 600;

SELECT @@TRANCOUNT;


-- reset the table
UPDATE [Sales].[SalesOrderDetail]
SET UnitPrice = 20.1865
WHERE  [SalesOrderDetailID]  = 600;

SELECT @@TRANCOUNT;









---view table in a different query window to verify no issues
SELECT * FROM [Sales].[SalesOrderDetail]
WHERE [SalesOrderDetailID]  = 600;