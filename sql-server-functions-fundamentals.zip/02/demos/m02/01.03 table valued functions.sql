-- Switch context
USE [SampleDB]
GO
-- We'll use the Employees table
SELECT * FROM Employees 
GO
-- We want all employees in the IT Department
SELECT * FROM Employees WHERE Department = 'IT'
GO
-- But that could also be a function
CREATE FUNCTION GetEmployeesByDepartment (@DeptName VARCHAR(50))
RETURNS TABLE 
AS
RETURN (
    SELECT EmployeeID, FirstName, LastName
    FROM Employees
    WHERE Department = @DeptName
)
GO
-- And now we can just use that function
SELECT * FROM GetEmployeesByDepartment('IT')
GO
-- We could also use a multi-statement function for the same result
-- For performance: Use Inline whenever possible!
CREATE FUNCTION GetEmployeesByDepartment_MV (@DeptName VARCHAR(50))
RETURNS @EmployeeTable TABLE (
    EmployeeID INT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50)
)
AS
BEGIN
    INSERT INTO @EmployeeTable (EmployeeID, FirstName, LastName)
    SELECT EmployeeID, FirstName, LastName
    FROM Employees
    WHERE Department = @DeptName

    RETURN
END
GO
-- Both functions deliver the same result: 
SELECT * FROM GetEmployeesByDepartment('IT')
SELECT * FROM GetEmployeesByDepartment_MV('IT')