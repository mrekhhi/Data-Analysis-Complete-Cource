-- Create the SampleDB Database
CREATE DATABASE [SampleDB]
GO
-- Switch context
USE [SampleDB]
GO
-- Create a table to store employee data
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Department VARCHAR(50),
	DateOfBirth VARCHAR(50)
)
GO
-- Insert some sample data into the Employees table
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, DateOfBirth)
VALUES 
    (1, 'John', 'Doe', 'IT','31/12/1953'),
    (2, 'Jane       ', 'Smith', 'HR','01/02/1971'),
    (3, 'Alice', 'Johnson', 'IT','08/08/1962'),
    (4, ' Bob', '    Brown', 'Finance','30/06/1974'),
    (5, NULL, 'White', 'Finance',NULL)
GO
-- Create a table to store item names
CREATE TABLE ItemNames (
    ItemID INT,
    ItemName NVARCHAR(100),
    LanguageID NVARCHAR(2)
)
GO
-- Populate the ItemNames table with sample data
INSERT INTO ItemNames (ItemID, ItemName, LanguageID)
VALUES
    (1, N'Item 1', N'EN'),
    (1, N'Produit 1', N'FR'),  
    (2, N'Item 2', N'EN'),
    (2, N'Produit 2', N'FR'),
    (3, N'Item 3', N'EN'),
    (3, N'Produit 3', N'FR')
GO
-- Another table for Exchangerates
CREATE TABLE ExchangeRates (
    FromCurrencyCode NVARCHAR(3),
	ToCurrencyCode NVARCHAR(3),
    ValidFrom DATE,
    Rate FLOAT
)
GO
-- And some data...
INSERT INTO ExchangeRates (FromCurrencyCode, ToCurrencyCode, ValidFrom, Rate)
VALUES 
    ('USD', 'EUR', '2023-10-31', 0.8542),
    ('USD', 'GBP', '2023-10-31', 0.7421),
    ('USD', 'EUR', '2023-11-30', 0.8415),
    ('USD', 'GBP', '2023-11-30', 0.7306),
    ('USD', 'EUR', '2023-12-31', 0.8317),
    ('USD', 'GBP', '2023-12-31', 0.7224),
    ('USD', 'EUR', '2024-01-31', 0.8203),
    ('USD', 'GBP', '2024-01-31', 0.7120)