-- Switch context
USE [SampleDB]
GO
-- Maybe not everyone should be able to see our employee's birthdays?
SELECT EmployeeID,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees
GO
-- Let's create another function that will only call the real function for some users...
CREATE FUNCTION dbo.ConvertStringToDate_Masked (@DTE NVARCHAR(50))
RETURNS DATE
AS
BEGIN
	DECLARE @DTE_Result DATE = '01.01.1900'
	IF NOT (UPPER(ORIGINAL_LOGIN()) IN ('TESTUSER')) 
		SET @DTE_Result = dbo.ConvertStringToDate(@DTE)
	RETURN @DTE_Result
END
GO
-- Works fine for me...
SELECT EmployeeID,dbo.ConvertStringToDate_Masked(DateOfBirth) DateOfBirth_DTE FROM Employees
GO
-- Let's try as testuser...
-- Grant permission only on some objects
CREATE USER [testuser] FOR LOGIN [testuser] WITH DEFAULT_SCHEMA=[dbo]
GRANT SELECT ON Employees TO [testuser]
GRANT EXECUTE ON ConvertStringToDate_Masked TO [testuser]