-- Let's start with a static cutoff date for reports
CREATE FUNCTION dbo.GetCutoffDate()
RETURNS DATE
AS
BEGIN
	RETURN '01/01/2020'
END
GO
SELECT dbo.GetCutoffDate()
GO
-- But can we do this dynamically?
ALTER FUNCTION dbo.GetCutoffDate()
RETURNS DATE
AS
BEGIN
	DECLARE @Years INT = 4
	RETURN DATEFROMPARTS(YEAR(GETDATE())-@Years, 1, 1)
END
GO
SELECT dbo.GetCutoffDate()