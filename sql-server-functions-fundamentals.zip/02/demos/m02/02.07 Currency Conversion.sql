-- Switch context
USE [SampleDB]
GO
-- Let's get some ExchangeRates...
SELECT * FROM ExchangeRates
GO
-- We want to know how long a rate is valid for...
SELECT ValidFrom,
	   ISNULL(Dateadd(d,-1,LEAD(validfrom) over (partition by FromCurrencyCode,ToCurrencyCode order by validfrom)),'01.01.2100') ValidTo
	   ,Rate 
	   FROM ExchangeRates WHERE FromCurrencyCode = 'USD' and ToCurrencyCode = 'EUR'
GO
-- Perfect usecase for a table function!
CREATE FUNCTION dbo.GetExchangeTable
(	
	@FromCurrencyCode nvarchar(3),
	@ToCurrencyCode nvarchar(3)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT ValidFrom,
	   ISNULL(Dateadd(d,-1,LEAD(validfrom) over (partition by FromCurrencyCode,ToCurrencyCode order by validfrom)),'01.01.2100') ValidTo
	   ,Rate 
	   FROM ExchangeRates WHERE FromCurrencyCode = @FromCurrencyCode and ToCurrencyCode = @ToCurrencyCode
)
GO
-- So we can do this...
SELECT * FROM dbo.GetExchangeTable('USD','EUR')
GO
-- But we can also use this table in another function...
CREATE FUNCTION dbo.GetCurrentUSDRate (@ToCurrencyCode nvarchar(3))
RETURNS float
AS
BEGIN
	DECLARE @Rate float
	SELECT @Rate=1/Rate FROM dbo.GetExchangeTable('USD',@ToCurrencyCode) WHERE GETDATE() between ValidFrom and ValidTo
	RETURN @Rate
END
GO
-- So now we can just do...
SELECT dbo.GetCurrentUSDRate('EUR')
GO
-- The alternative would have been: 
SELECT 1/Rate from (SELECT ValidFrom,
	   ISNULL(Dateadd(d,-1,LEAD(validfrom) over (partition by FromCurrencyCode,ToCurrencyCode order by validfrom)),'01.01.2100') ValidTo
	   ,Rate 
	   FROM ExchangeRates WHERE FromCurrencyCode = 'USD' and ToCurrencyCode = 'EUR' ) a WHERE GETDATE() between ValidFrom and ValidTo
	   