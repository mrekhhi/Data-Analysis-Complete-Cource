-- Switch context
USE [SampleDB]
GO
-- We'll use the Employees table again
SELECT * FROM Employees 
GO
-- We want their FullName
SELECT EmployeeID,FirstName + ' ' + LastName FullName FROM Employees
GO
-- We need to do some cleanup...
SELECT EmployeeID,TRIM(CONCAT(TRIM(FirstName),' ',TRIM(LastName))) FullName FROM Employees
GO
-- Now imagine having to do the same in multiple places...
CREATE FUNCTION dbo.GetFullName
(
	@FirstName NVARCHAR(50),
	@LastName NVARCHAR(50)
)
RETURNS INT
AS
BEGIN
	RETURN TRIM(CONCAT(TRIM(@FirstName),' ',TRIM(@LastName)))
END
GO
-- Now we can call the function
SELECT EmployeeID,dbo.GetFullName(FirstName,LastName) FullName FROM Employees
GO
-- Datatypes do matter!
ALTER FUNCTION dbo.GetFullName
(
	@FirstName NVARCHAR(50),
	@LastName NVARCHAR(50)
)
RETURNS NVARCHAR(101)
AS
BEGIN
	RETURN TRIM(CONCAT(TRIM(@FirstName),' ',TRIM(@LastName)))
END
GO
-- Let's try again
SELECT EmployeeID,dbo.GetFullName(FirstName,LastName) FullName FROM Employees