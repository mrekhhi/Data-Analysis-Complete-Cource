-- Switch context
USE [SampleDB]
GO
-- Some of our employees have wrong birthdays...
SELECT EmployeeID,DateOfBirth,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees 
GO
-- Time for a validation function
CREATE FUNCTION dbo.IsValidDTE(@DTE NVARCHAR(50))
RETURNS BIT
AS
BEGIN
	DECLARE @Result BIT = 1
	DECLARE @Day INT
	DECLARE @Month INT
	DECLARE @Year INT
	IF NOT (@DTE like '__/__/____') SET @Result = 0
	SET @Day =		ISNULL(TRY_CAST(SUBSTRING(@DTE,1,2) AS INT),-1)
	SET @Month =	ISNULL(TRY_CAST(SUBSTRING(@DTE,4,2) AS INT),-1)
	SET @Year =		ISNULL(TRY_CAST(SUBSTRING(@DTE,7,4) AS INT),0)
	IF NOT (@Day between 1 and 31) SET @Result = 0
	IF NOT (@Month between 1 and 12) SET @Result = 0
	IF NOT (@Year > 1900) SET @Result = 0
	RETURN @Result
END
GO
-- We can now validate our dates
SELECT EmployeeID,DateOfBirth,dbo.IsValidDTE(DateOfBirth) DateOfBirth_DTE FROM Employees 
GO
-- And also filter on it
SELECT EmployeeID,DateOfBirth DateOfBirth_DTE FROM Employees WHERE dbo.IsValidDTE(DateOfBirth) = 0