-- Switch context
USE [SampleDB]
GO
-- We'll look at items...
SELECT * FROM ItemNames
GO
-- But we care for a specific language and item...
SELECT * FROM ItemNames WHERE ItemID = 2 and LanguageID = 'EN'
GO
-- Let's add that to another function...
CREATE FUNCTION dbo.GetItemName (@ItemID INT, @LanguageID NVARCHAR(2))
RETURNS NVARCHAR(50)
AS
BEGIN
	DECLARE @ItemName NVARCHAR(50)
	SELECT @ItemName=ItemName FROM ItemNames WHERE ItemID = @ItemID and LanguageID = @LanguageID
	RETURN @ItemName
END
GO
-- We can call it
SELECT dbo.GetItemName(1,'EN')
GO
-- But we mostly want english names...
ALTER FUNCTION dbo.GetItemName (@ItemID INT, @LanguageID NVARCHAR(2) = 'EN')
RETURNS NVARCHAR(50)
AS
BEGIN
	DECLARE @ItemName NVARCHAR(50)
	SELECT @ItemName=ItemName FROM ItemNames WHERE ItemID = @ItemID and LanguageID = @LanguageID
	RETURN @ItemName
END
GO
-- So we can do all this...
SELECT dbo.GetItemName(1,'EN')
SELECT dbo.GetItemName(2,'FR')
-- And this
SELECT dbo.GetItemName(1, default)
-- but not this
SELECT dbo.GetItemName(1)
-- but this:
DECLARE @ItemName NVARCHAR(50)
EXECUTE @ItemName = dbo.GetItemName 1
SELECT  @ItemName