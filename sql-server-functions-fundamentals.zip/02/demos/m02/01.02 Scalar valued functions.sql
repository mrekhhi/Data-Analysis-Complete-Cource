-- Let's do a simple addition
SELECT 1+2
GO
-- We could do that in a function
CREATE FUNCTION dbo.AddValues
(
	@Val_1 int,
	@Val_2 int
)
RETURNS int
AS
BEGIN
	RETURN @Val_1+@Val_2
END
GO
-- Now we can call the function
SELECT dbo.AddValues(1,2)