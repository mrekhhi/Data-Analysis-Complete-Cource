-- Switch context
USE [SampleDB]
GO
-- Let's look at some execution plans...
SELECT dbo.AddValues(1,2)
SELECT dbo.ConvertStringToDate('EUR')
SELECT EmployeeID,DateOfBirth,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees 
SELECT dbo.GetCurrentUSDRate('EUR')

-- Inlining scalar UDFs does not work pre SQL Server 2019
-- Let us use COMPAT Level 140 (SQL Server 2017)
USE [master]
GO
ALTER DATABASE [SampleDB] SET COMPATIBILITY_LEVEL = 140
GO
USE [SampleDB]
GO
SELECT dbo.ConvertStringToDate('EUR')
GO
-- Set back to 2019 or higher
USE [master]
GO
ALTER DATABASE [SampleDB] SET COMPATIBILITY_LEVEL = 160
GO
USE [SampleDB]
GO
SELECT dbo.ConvertStringToDate('EUR')