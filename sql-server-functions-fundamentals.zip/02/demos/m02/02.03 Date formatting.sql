-- Switch context
USE [SampleDB]
GO
-- We'll use the Employees table again
SELECT * FROM Employees 
GO
-- We want their birthday in a proper datatype
SELECT EmployeeID,cast(DateOfBirth as Date) FROM Employees
GO
-- We need to do some cleanup...
SELECT EmployeeID,ISNULL(DATEFROMPARTS(RIGHT(DateOfBirth,4),SUBSTRING(DateOfBirth,4,2),LEFT(DateOfBirth,2)),'01.01.1900') DateOfBirth_DTE FROM Employees
GO
-- Now imagine having to do the same in multiple places AGAIN...
CREATE FUNCTION dbo.ConvertStringToDate
(
	@DTE NVARCHAR(50)
)
RETURNS DATE
AS
BEGIN
	RETURN ISNULL(DATEFROMPARTS(RIGHT(@DTE,4),SUBSTRING(@DTE,4,2),LEFT(@DTE,2)),'01.01.1900')
END
GO
-- Now we can call the function
SELECT EmployeeID,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees
GO
-- This becomes even more useful with invalid dates: 
UPDATE Employees SET DateOfBirth = 'no idea' WHERE EmployeeID = 3
UPDATE Employees SET DateOfBirth = '13/13/1974' WHERE EmployeeID = 4
SELECT * FROM Employees
GO
-- Our original query fails:
SELECT EmployeeID,ISNULL(DATEFROMPARTS(RIGHT(DateOfBirth,4),SUBSTRING(DateOfBirth,4,2),LEFT(DateOfBirth,2)),'01.01.1900') DateOfBirth_DTE FROM Employees
GO
-- So does our function...
SELECT EmployeeID,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees
GO
-- But fixing it in the function is relatively easy, including some fallback logic:
ALTER FUNCTION dbo.ConvertStringToDate (@DTE NVARCHAR(50))
RETURNS DATE
AS
BEGIN
	DECLARE @Result_DTE DATE
	DECLARE @Day INT
	DECLARE @Month INT
	DECLARE @Year INT
	IF NOT (@DTE like '__/__/____') SET @DTE = '01/01/1900'
	SET @Day =		ISNULL(TRY_CAST(SUBSTRING(@DTE,1,2) AS INT),1)
	SET @Month =	ISNULL(TRY_CAST(SUBSTRING(@DTE,4,2) AS INT),1)
	SET @Year =		ISNULL(TRY_CAST(SUBSTRING(@DTE,7,4) AS INT),1900)
	IF NOT (@Day between 1 and 31) SET @Day = 1
	IF NOT (@Month between 1 and 12) SET @Month = 1
	SET @Result_DTE = ISNULL(DATEFROMPARTS(@Year,@Month,@Day),'01.01.1900')
	RETURN @Result_DTE
END
GO
-- And here we go: 
SELECT EmployeeID,DateOfBirth,dbo.ConvertStringToDate(DateOfBirth) DateOfBirth_DTE FROM Employees 